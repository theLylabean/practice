import { useState } from "react";
import Counter from "./components/Counter"
import './index.css'

function App() {
  const [alert, setAlert] = useState('');

  return (
    <>
      <Counter alert={alert} setAlert={setAlert}/>
    </>
  )
}

export default App
