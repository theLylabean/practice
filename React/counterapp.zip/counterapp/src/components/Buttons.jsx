</button>
{/* setCount(count > 0 ? count - 1 : 0) */}
<button 
  onClick={() => {
    if (count === 0) {
        // setAlert("Sorry! The limit does not exist!");
    } else {
    const subtractCount = count - 1;
    if (subtractCount === 0) {
        // setAlert(`You have reached ${subtractCount}. DO NOT PASS GO. DO NOT COLLECT 32 CREDITS.`);
        setCount(0);
    } else {
        setCount(count > 0 ? subtractCount : 0);
        // setAlert('');
    }}
  }}
  disabled={!!alert}
>
  Subtract 1
</button>
<button 
  onClick={() => {
    if (count === 0) {
        // setAlert("Haven't I been reset enough already?");
    } else {
        setCount(0);
        // setAlert('');
    }
  }}
  disabled={!!alert}
>
  Reset
</button>
</div>
{alert && (
<div id='alert' style={{
    position: 'fixed',
    bottom: '20px',
    transform: 'translateX(-50%)',
    backgroundColor: '#ffdddd',
    color: '#990000',
    padding: '1rem',
    borderRadius: '8px',
    marginBottom: '1rem',
    border: '1px solid #990000',
    textAlign: 'center',
    zIndex: 1000,
    minWidth: '300px',
}}>
    {alert}
</div>